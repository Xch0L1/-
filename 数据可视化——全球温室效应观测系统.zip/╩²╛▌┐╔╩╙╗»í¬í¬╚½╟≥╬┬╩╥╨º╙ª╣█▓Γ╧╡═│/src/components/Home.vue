<template>
  <div class='home'>
    <Header></Header>
    <el-container class='content'>
      <Menu></Menu>
      <el-main>
        <el-card>
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item >首页</el-breadcrumb-item>
            <el-breadcrumb-item v-for="(item, index) in $route.matched" :key='index'>
              {{item.name}}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </el-card>
        <el-card class="chart-card" v-if="isHomePage">
          <div  class="introduction" style="color: red; height: 10px"></div>
          <p>欢迎来到全球温室效应观测系统！</p>
          <p>我来讲解一下系统的使用：</p>
          <p>首先在左侧的目录中你可以选择想要查看的板块。</p>
          <p>需要注意的是在碳排放板块中，你要先导入需要显示的CSV文件CO2.csv，然后才能看到数据的可视化。</p>
          <p>需要注意的是在气温板块中，你要先导入需要显示的CSV文件processed_city_temperature.csv，然后才能看到数据的可视化。</p>
          <p>现在开始使用吧！</p>
        </el-card>
        <div class='cont'>
          <router-view></router-view>
        </div>
        <Footer></Footer>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import Header from './common/Header'
import Footer from './common/Footer'
import Menu from './common/Menu'
export default {
  components: {
    Header,
    Footer,
    Menu
  },
  name: 'Home',
  data () {
    return {}
  },
  computed: {
    isHomePage () {
      // 判断当前路由是否是Home页面
      return this.$route.name === '数据展示'
    }
  },
  created () {},
  methods: {}
}
</script>

<style scoped lang='scss'>
.home {
  .content {
    position: absolute;
    width: 100%;
    top: 60px;
    bottom: 0;
    .cont {
      margin: 20px 0;
    }
  }
}
.introduction {
  margin-bottom: 20px; /* 调整引言与el-card之间的间距 */
}
</style>
