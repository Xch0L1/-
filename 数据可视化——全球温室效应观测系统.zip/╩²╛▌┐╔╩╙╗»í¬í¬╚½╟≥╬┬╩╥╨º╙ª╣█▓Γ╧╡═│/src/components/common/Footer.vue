<template>
  <div class='footer'>
    <el-card>
      全球温室效应观测系统
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'Footer',
  data () {
    return {}
  }
}
</script>

<style scoped lang='scss'>
</style>
