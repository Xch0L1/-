<template>
  <div class='header'>
      <el-header>
          <div class='title'>全球温室效应观测系统</div>
          <div>{{name}}</div>
      </el-header>
  </div>
</template>

<script>
export default {
  name: 'Login',
  data () {
    return {
      name: ''
    }
  },
  created () {
    this.name = localStorage.getItem('username')
  }
}
</script>

<!-- Add 'scoped' attribute to limit CSS to this component only -->
<style scoped lang='scss'>
.header {
    .el-header {
        background: #39ad69;
        color: #fff;
        line-height: 60px;
        display: flex;
        justify-content: space-between;
        .title {
            width: 240px;
            font-size: 24px;
        }
    }
}
</style>
