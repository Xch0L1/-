<template>
  <div class="city-view">
    <el-container class="content">
      <el-main>
        <div class="city-view">
          <el-card class="chart-card">
            <div id="main1" style="height: 950px"></div>
            <p>{{ countryNames.join(', ') }}</p>
          </el-card>
          <div class="button-wrapper">
            <el-select v-model="selectedCountryCodes" placeholder="选择国家" multiple>
              <el-option
                v-for="countryCode in Object.keys(citiesData)" :key="countryCode" :label="citiesData[countryCode].name" :value="countryCode"
              ></el-option>
            </el-select>
            <el-button type="danger" @click="resetChart">图像重置</el-button> <!-- 新增的按钮 -->
            <label class="file-upload" for="upload_input">
              选择文件
            </label>
            <div v-if="selectedFileName" class="selected-file">{{ selectedFileName }}</div>
            <input id="upload_input" ref="fileInput" class="hide" type="file" accept=".csv" @change="onUpload" />
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>

import * as echarts from 'echarts'
import Papa from 'papaparse'

export default {
  name: 'CityView',
  data () {
    return {
      data: [],
      selectedCountryCodes: [],
      countryNames: [],
      countries: [],
      citiesData: {},
      selectedFileName: null
    }
  },
  mounted () {
    this.loadData()
    this.$nextTick(() => {
      this.initChart()
    })
  },
  watch: {
    selectedCountryCodes (newCountryCodes) {
      this.renderChart(newCountryCodes)
    }
  },
  methods: {
    resetChart () {
      // 重置选择的国家和折线图
      this.selectedCountryCodes = []
      this.chart.clear() // 清空图表
      this.countryNames = []
    },
    onUpload (event) {
      const file = event.target.files[0]
      if (file) {
        this.selectedFileName = file.name
      }
    },
    initChart () {
    // 初始化折线图
      this.chart = echarts.init(document.getElementById('main1'))
    },
    getCitiesData (data) {
      const citiesData = {}
      data.forEach(item => {
        const countryCode = item['country_code']
        const countryName = item['country_name']
        if (!citiesData[countryCode]) {
          citiesData[countryCode] = { name: countryName }
        }
      })
      return citiesData
    },
    renderChart (selectedCountryCodes) {
      // 确定 x 轴数据（年份）
      const years = Array.from({ length: 2017 - 2008 }, (_, index) => (2008 + index).toString())
      // 清空折线图数据
      if (selectedCountryCodes.length === 0) {
        const option = {
          tooltip: {
            trigger: 'axis'
          },
          legend: {
            data: [years]
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: []
          },
          yAxis: {
            type: 'value'
          },
          series: []
        }
        this.chart.setOption(option)
        this.countryNames = []
      } else {
        // 构建 series 数组
        const series = selectedCountryCodes.map(countryCode => {
          const countryData = this.data
            .filter(item => item['country_code'] === countryCode)
            .sort((a, b) => a['year'] - b['year']) // 按年份排序
          const countryName = this.citiesData[countryCode].name
          // 确定每个年份的数据，如果没有数据则设为 null
          const values = years.map(year => {
            const foundItem = countryData.find(item => item['year'] === year)
            return foundItem ? foundItem['value'] : null
          })
          return {
            data: values,
            type: 'line',
            name: countryName
          }
        })
        const option = {
          tooltip: {
            trigger: 'axis'
          },
          legend: {
            data: [years]
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: years
          },
          yAxis: {
            type: 'value'
          },
          series: series
        }
        this.chart.setOption(option)
        this.countryNames = selectedCountryCodes.map(
          countryCode => this.citiesData[countryCode].name
        )
      }
    },
    loadData () {
      // 获取input[type="file"]元素
      const fileInput = this.$refs.fileInput
      // 添加change事件监听器
      fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0]
        if (file) {
          const reader = new FileReader()
          reader.readAsText(file, 'utf-8')
          reader.onload = () => {
            const content = reader.result
            // 使用PapaParse解析CSV文件
            Papa.parse(content, {
              header: true,
              complete: (result) => {
                const data = result.data
                console.log('yes', data)
                // 将数据赋值给组件的data属性
                this.data = this.preprocessData(data)
                console.log('data', this.data)
                this.citiesData = this.getCitiesData(data)
              }
            })
          }
          reader.onerror = () => {
            console.error('读取文件失败！')
          }
        }
      })
      // 模拟点击input[type="file"]元素，弹出文件选择窗口
      fileInput.click()
    },
    preprocessData (data) {
      data.pop()
      // 获取所有国家的列表
      const countries = [...new Set(data.map(item => item['country_code']))]
      console.log('countries', countries)
      // 获取每个国家的年份范围
      const yearRanges = {}
      countries.forEach(countryCode => {
        const years = data.filter(item => item['country_code'] === countryCode).map(item => +item['year'])
        let minYear = Infinity
        let maxYear = -Infinity
        years.forEach(year => {
          if (!isNaN(year)) {
            if (year < minYear) minYear = year
            if (year > maxYear) maxYear = year
          }
        })
        yearRanges[countryCode] = { minYear, maxYear }
      })
      console.log('yearRanges', yearRanges)
      // 找到所有国家的共同年份范围
      let minCommonYear = Math.max(...Object.values(yearRanges).map(({ minYear }) => minYear))
      let maxCommonYear = Math.min(...Object.values(yearRanges).map(({ maxYear }) => maxYear))
      console.log('minCommonYear', minCommonYear)
      console.log('maxCommonYear', maxCommonYear)
      // 过滤数据，只保留在共同年份范围内的数据
      const filteredData = data.filter(item => {
        return item['year'] >= minCommonYear && item['year'] <= maxCommonYear
      })
      console.log('filteredData', filteredData)
      return filteredData
    }
  }
}
</script>

<style scoped lang="scss">
.city-view {
  width: 100%;
  height: 100%;
  display: flex;
}
.chart-card {
  width: 90%;
}
.button-wrapper {
  width: 10%;
  position: relative;
}
.el-select,
.hide,
.file-upload {
  margin-bottom: 420px; /* 将选择国家按钮下移 */
}
.el-select {
  width: 100%;
}
.hide {
  display: none;
}
.file-upload {
  cursor: pointer;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #ffffff;
}
.file-upload:hover {
  background-color: #e0e0e0;
}
.selected-file {
    margin-top: -20px; // 调整文件名显示位置
}
.button-wrapper {
  width: 10%; // 调整按钮宽度
  display: flex;
  flex-direction: column;
}
.el-button {
  margin-top: 10px; // 调整按钮与选择框之间的间距
}
</style>
