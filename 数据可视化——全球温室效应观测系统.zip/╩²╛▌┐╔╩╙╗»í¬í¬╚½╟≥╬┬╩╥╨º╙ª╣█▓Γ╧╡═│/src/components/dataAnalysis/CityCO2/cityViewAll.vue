<template>
  <div class="city-view">
    <el-container class="content">
      <el-main>
        <div class="city-view">
          <el-card class="chart-card">
            <div id="main1" style="height: 950px"></div>
            <p>{{ countryName }}</p>
          </el-card>
          <div class="button-wrapper">
            <el-select v-model="selectedCountryCode" placeholder="选择国家">
              <el-option
                v-for="countryCode in Object.keys(citiesData)" :key="countryCode" :label="citiesData[countryCode].name" :value="countryCode"
              ></el-option>
            </el-select>
            <label class="file-upload" for="upload_input">
              选择文件
            </label>
            <div v-if="selectedFileName" class="selected-file">{{ selectedFileName }}</div>
            <input id="upload_input" ref="fileInput" class="hide" type="file" accept=".csv" @change="onUpload" />
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import Papa from 'papaparse'

export default {
  name: 'CityView',
  data () {
    return {
      data: [],
      selectedCountryCode: '',
      countryName: '',
      countryCode: '',
      year: '',
      countries: [],
      citiesData: {},
      selectedFileName: null // 新增的属性用于保存选择的文件名
    }
  },
  mounted () {
    this.loadData()
    this.$nextTick(() => {
      this.initChart()
    })
  },
  watch: {
    selectedCountryCode (newCountryCode) {
      this.renderChart(newCountryCode)
    }
  },
  methods: {
    onUpload (event) {
      const file = event.target.files[0]
      if (file) {
        this.selectedFileName = file.name
      }
    },
    initChart () {
      // 初始化柱状图
      this.chart = echarts.init(document.getElementById('main1'))
    },
    getCitiesData (data) {
      const citiesData = {}
      data.forEach(item => {
        const countryCode = item['country_code']
        const countryName = item['country_name']
        if (!citiesData[countryCode]) {
          citiesData[countryCode] = { name: countryName }
        }
      })
      return citiesData
    },
    renderChart (selectedCountryCode) {
      const countryData = this.data.filter(item => item['country_code'] === selectedCountryCode)
      const countryName = this.citiesData[selectedCountryCode].name
      const years = countryData.map(item => item['year'])
      const values = countryData.map(item => item['value'])
      const option = {
        xAxis: {
          type: 'category',
          data: years
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: values,
            type: 'bar', // 更改图表类型为柱状图
            name: countryName
          }
        ]
      }
      this.chart.setOption(option)
    },
    loadData () {
      // 获取input[type="file"]元素
      const fileInput = this.$refs.fileInput
      // 添加change事件监听器
      fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0]
        if (file) {
          const reader = new FileReader()
          reader.readAsText(file, 'utf-8')
          reader.onload = () => {
            const content = reader.result
            // 使用PapaParse解析CSV文件
            Papa.parse(content, {
              header: true,
              complete: (result) => {
                const data = result.data
                console.log('yes', data)
                // 将数据赋值给组件的data属性
                this.data = data
                console.log('data', this.data)
                this.citiesData = this.getCitiesData(data)
              }
            })
          }
          reader.onerror = () => {
            console.error('读取文件失败！')
          }
        }
      })
      // 模拟点击input[type="file"]元素，弹出文件选择窗口
      fileInput.click()
    }
  }
}
</script>

<style scoped lang="scss">
.city-view {
  width: 100%;
  height: 100%;
  display: flex;
}
.chart-card {
  width: 90%;
}
.button-wrapper {
  width: 10%;
  position: relative;
}
.el-select,
.hide,
.file-upload {
  margin-bottom: 420px;
}
.el-select {
  width: 100%;
}
.hide {
  display: none;
}
.file-upload {
  cursor: pointer;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #ffffff;
}
.file-upload:hover {
  background-color: #e0e0e0;
}
.selected-file {
    margin-top: 15px;
}
</style>
