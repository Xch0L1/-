<template>
  <div class="top-view">
    <el-container class="content">
      <el-main>
        <div class="top-view">
          <el-card class="chart-card">
            <div id="main1" style="height: 950px"></div>
            <p>{{ countryName }}</p>
          </el-card>
          <div class="button-wrapper">
            <!-- <el-select v-model="selectedCountryCode" placeholder="选择国家">
              <el-option
                v-for="countryCode in Object.keys(citiesData)" :key="countryCode" :label="citiesData[countryCode].name" :value="countryCode"
              ></el-option>
            </el-select> -->
            <label class="file-upload" for="upload_input">
              选择文件
            </label>
            <div v-if="selectedFileName" class="selected-file">{{ selectedFileName }}</div>
            <input id="upload_input" ref="fileInput" class="hide" type="file" accept=".csv" @change="onUpload" />
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>

import * as echarts from 'echarts'
import Papa from 'papaparse'

export default {
  name: 'TopView',
  data () {
    return {
      data: [],
      selectedCountryCode: '',
      countryName: '',
      countryCode: '',
      year: '',
      countries: [],
      citiesData: {},
      selectedFileName: null // 新增的属性用于保存选择的文件名
    }
  },
  mounted () {
    this.loadData()
    this.initChart()
  },
  watch: {
    data () {
      this.renderChart()
    }
  },
  methods: {
    onUpload (event) {
      const file = event.target.files[0]
      if (file) {
        this.selectedFileName = file.name
        // this.loadData()
      }
    },
    initChart () {
    // 初始化饼图
      this.chart = echarts.init(document.getElementById('main1'))
      this.renderChart()
    },
    getCitiesData (data) {
      const citiesData = {}
      data.forEach(item => {
        const countryCode = item['country_code']
        const countryName = item['country_name']
        if (!citiesData[countryCode]) {
          citiesData[countryCode] = { name: countryName }
        }
      })
      return citiesData
    },
    renderChart () {
      const option = {
        tooltip: {
          trigger: 'item'
        },
        legend: {
          top: '5%',
          left: 'center'
        },
        series: [
          {
            name: 'CO2 Emission',
            type: 'pie',
            radius: ['40%', '70%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            label: {
              show: false,
              position: 'center'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 40,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: this.data.map(item => ({
              value: item.value,
              name: item.country_name
            }))
          }
        ]
      }
      this.chart.setOption(option)
    },
    loadData () {
      // 获取input[type="file"]元素
      const fileInput = this.$refs.fileInput
      // 添加change事件监听器
      fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0]
        if (file) {
          const reader = new FileReader()
          reader.readAsText(file, 'utf-8')
          reader.onload = () => {
            const content = reader.result
            // 使用PapaParse解析CSV文件
            Papa.parse(content, {
              header: true,
              complete: (result) => {
                const data = result.data
                console.log('yes', data)
                // 将数据赋值给组件的data属性
                this.data = this.preprocessData(data)
                console.log('data', this.data)
                this.citiesData = this.getCitiesData(data)
              }
            })
          }
          reader.onerror = () => {
            console.error('读取文件失败！')
          }
        }
      })
      // 模拟点击input[type="file"]元素，弹出文件选择窗口
      fileInput.click()
    },
    preprocessData (data) {
      // 创建一个对象，用于存储每个国家的年度总碳排放量和年份数
      const countryDataMap = {}
      // 遍历数据，计算每个国家的年度总碳排放量和年份数
      data.forEach((item) => {
        const countryCode = item['country_code']
        const countryName = item['country_name']
        // 添加以下过滤条件
        if (!countryName || /\s[a-z]/.test(countryName) || countryName === 'World' || countryName.includes('&') || countryName.includes('Asia') || countryName.includes('Europe') || countryName.includes('America') || countryName.includes('Africa')) {
          return // 如果国家名为空或包含空格后小写字母，则跳过
        }
        const year = +item['year']
        const value = +item['value']
        if (!isNaN(year) && !isNaN(value)) {
          if (!countryDataMap[countryCode]) {
            countryDataMap[countryCode] = { total: 0, count: 0, countryName: countryName }
          }
          countryDataMap[countryCode].total += value
          countryDataMap[countryCode].count += 1
        }
      })
      // 计算每个国家的年度平均值
      const averagedData = Object.keys(countryDataMap).map((countryCode) => {
        const countryData = countryDataMap[countryCode]
        if (countryData && countryData.count > 0) {
          const averageValue = countryData.total / countryData.count
          return { country_code: countryCode, country_name: countryData.countryName, value: averageValue }
        }
      })
      // 过滤掉 null 值
      const filteredData = averagedData.filter((item) => item !== null)
      // 按平均值降序排序
      filteredData.sort((a, b) => b.value - a.value)
      // 获取前 9 个国家的数据
      const topCountriesData = filteredData.slice(0, 9)
      // 计算其他国家的平均值并添加到 other 中
      const otherAverageValue = filteredData.slice(9).reduce((sum, item) => sum + item.value, 0) / (filteredData.length - 9)
      topCountriesData.push({ country_code: 'OTHER', country_name: 'Other Countries', value: otherAverageValue })
      // 输出前 10 个国家的数据
      console.log('Top 10 Countries:', topCountriesData)
      // 返回前 10 个国家的平均值数据
      return topCountriesData
    }
  }
}
</script>

<style scoped lang="scss">
.top-view {
  width: 100%;
  height: 100%;
  display: flex;
}
.chart-card {
  width: 90%;
}
.button-wrapper {
  width: 10%;
  position: relative;
}
.el-select,
.hide,
.file-upload {
  margin-bottom: 420px; /* 将选择国家按钮下移 */
}
.el-select {
  width: 100%;
}
.hide {
  display: none;
}
.file-upload {
  cursor: pointer;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #ffffff;
}
.file-upload:hover {
  background-color: #e0e0e0;
}
.selected-file {
    margin-top: 15px; // 调整文件名显示位置
}
</style>
