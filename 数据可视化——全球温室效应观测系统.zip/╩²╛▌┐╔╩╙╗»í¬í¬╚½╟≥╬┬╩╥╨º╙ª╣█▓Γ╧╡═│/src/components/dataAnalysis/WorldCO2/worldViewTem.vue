<template>
  <div class="map-data">
    <label class="file-upload" for="upload_input">选择文件</label>
    <div v-if="selectedFileName" class="selected-file">{{ selectedFileName }}</div>
    <input id="upload_input" ref="fileInput" class="hide" type="file" accept=".csv" @change="onUpload" />
    <div>
      <button @click="prevYear">上一年</button>
      <label for="yearSelect">选择年份:</label>
      <select id="yearSelect" v-model="currentYear" @change="updateMapData">
        <option v-for="year in availableYears" :key="year" :value="year">{{ year }}</option>
      </select>
      <button @click="nextYear">下一年</button>
    </div>
    <div id="main" style="width: 100%; height: 920px;"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import geoJson from '../../../assets/worldView.json'
import Papa from 'papaparse'

export default {
  data () {
    return {
      selectedFileName: null,
      countriesData: [],
      citiesData: {},
      currentYear: 2012,
      timer: null,
      visualMapMin: 40,
      visualMapMax: 100,
      availableYears: [...Array(2020).keys()].slice(1995, 2020)
    }
  },
  mounted () {
    this.initMap()
  },
  methods: {
    initMap () {
      echarts.registerMap('world', geoJson)
      const myChart = echarts.init(document.getElementById('main'))

      const option = {
        series: [
          {
            type: 'map',
            map: 'world',
            label: {
              show: false
            },
            itemStyle: {
              emphasis: {
                areaColor: '#FFD700'
              }
            },
            data: [],
            tooltip: {
              show: true,
              formatter: function (params) {
                if (params.data) {
                  return `${params.name}: ${params.value}`
                }
                return ''
              }
            }
          }
        ],
        visualMap: {
          min: 40,
          max: 100,
          inRange: {
            color: ['lightskyblue', 'yellow', 'orangered']
          }
        }
      }

      myChart.setOption(option)
      this.updateMapData()
    },
    updateMapData () {
      const myChart = echarts.init(document.getElementById('main'))
      const option = {
        tooltip: {
          trigger: 'item',
          show: true,
          formatter: function (params) {
            if (params.data) {
              return `${params.name}: ${params.value}`
            }
            return ''
          }
        },
        series: [
          {
            type: 'map',
            map: 'world',
            label: {
              show: false
            },
            itemStyle: {
              emphasis: {
                areaColor: '#FFD700'
              }
            },
            data: this.countriesData.filter(item => item.year === this.currentYear).map(item => {
              return {
                name: item.name,
                value: item.value
              }
            })
          }
        ],
        visualMap: {
          min: 40,
          max: 100,
          inRange: {
            color: ['lightskyblue', 'yellow', 'orangered']
          }
        }
      }
      myChart.setOption(option)
      // 添加鼠标悬浮事件，显示提示框
      myChart.on('mouseover', function (params) {
        if (params.componentType === 'series') {
          myChart.dispatchAction({
            type: 'showTip',
            seriesIndex: params.seriesIndex,
            dataIndex: params.dataIndex
          })
        }
      })

      // 添加鼠标离开事件，隐藏提示框
      myChart.on('mouseout', function (params) {
        if (params.componentType === 'series') {
          myChart.dispatchAction({
            type: 'hideTip',
            seriesIndex: params.seriesIndex,
            dataIndex: params.dataIndex
          })
        }
      })
    },
    onUpload (event) {
      const file = event.target.files[0]
      if (file) {
        const reader = new FileReader()
        reader.readAsText(file, 'utf-8')
        reader.onload = () => {
          const content = reader.result
          Papa.parse(content, {
            header: true,
            complete: (result) => {
              const data = result.data
              this.countriesData = this.preprocessData(data)
              this.selectedFileName = file.name
              this.updateMapData()
            }
          })
        }
        reader.onerror = () => {
          console.error('读取文件失败！')
        }
      }
    },
    preprocessData (data) {
      data.pop()
      const countryNameMap = {
        // 在这里添加你的国家名称映射关系
        'Iceland': 'Iceland',
        'US': 'United States',
        'Egypt, Arab Rep.': 'Ecuador',
        'Congo, Dem. Rep.': 'Chile',
        'Congo, Rep.': 'Paraguay',
        'Myanmar (Burma)': 'Myanmar',
        'Malawi': 'Mali',
        'Czech Republic': 'Czech',
        'Central African Republic': 'Central African Rep.',
        'South Korea': 'Korea',
        'North Korea': 'Dem. Rep. Korea'
      }
      const processedData = []
      data.forEach(item => {
        const fileCountryName = item['country_name']
        const mapCountryName = countryNameMap[fileCountryName] || fileCountryName // 使用映射表，如果没有映射关系则使用原名称
        const value = +item['value']
        const year = +item['year']
        if (mapCountryName && !isNaN(value) && !isNaN(year) && year >= 1990) {
          processedData.push({ name: mapCountryName, year, value })
        }
      })
      console.log('processedData', processedData)
      // 更新 visualMap 的最小和最大值
      // this.visualMapMin = Math.min(...processedData.map(item => item.value))
      // this.visualMapMax = Math.max(...processedData.map(item => item.value))

      return processedData
    },
    prevYear () {
      this.currentYear = Math.max(this.currentYear - 1, 1990)
      this.updateMapData()
    },
    nextYear () {
      this.currentYear = Math.min(this.currentYear + 1, 2019)
      this.updateMapData()
    }
  }
}
</script>

<style lang="scss">
.map-data {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  #main {
    flex: 1;
    width: 100%;
    height: 600px;
  }
}
.hide {
  display: none;
}
.file-upload {
  cursor: pointer;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #ffffff;
  margin-top: 10px;
}
.file-upload:hover {
  background-color: #e0e0e0;
}
.selected-file {
  margin-top: 10px;
}
</style>
