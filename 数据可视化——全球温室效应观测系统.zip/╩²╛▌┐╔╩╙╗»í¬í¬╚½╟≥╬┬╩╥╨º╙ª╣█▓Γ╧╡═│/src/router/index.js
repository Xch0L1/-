import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: '数据展示',
      iconClass: 'el-icon-sunny',
      // redirect: '/home/cityview',
      component: () => import('@/components/Home'),
      children: [
        {
          path: '/home/cityviewall',
          name: '世界各地区近年碳排放展示',
          iconClass: 'el-icon-sunny',
          component: () => import('@/components/dataAnalysis/CityCO2/cityViewAll')
        },
        {
          path: '/home/cityview',
          name: '世界各地区近年碳排放对比',
          iconClass: 'el-icon-sunny',
          component: () => import('@/components/dataAnalysis/CityCO2/cityView')
        },
        {
          path: '/home/topview',
          name: '近年世界各国平均碳排放展示',
          iconClass: 'el-icon-sunny',
          component: () => import('@/components/dataAnalysis/TopCO2/topView')
        },
        {
          path: '/home/worldView',
          name: '近年世界各国碳排放总览',
          iconClass: 'el-icon-sunny',
          component: () => import('@/components/dataAnalysis/WorldCO2/worldView')
        },
        {
          path: '/home/worldViewTem',
          name: '近年世界各国气温总览',
          iconClass: 'el-icon-sunny',
          component: () => import('@/components/dataAnalysis/WorldCO2/worldViewTem')
        }
      ]
    }
  ],
  mode: 'history'
})
